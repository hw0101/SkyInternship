//
//  Task.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/4/25.
//

import Foundation


//任務類
class Task {
    
    //變量設置
    var promulgator: String
    var accepter: String
    var time: String
    var task_id: String
    var project: String
    var function_module: String
    var plan_time: String
    var practical_time: String
    var subentry_evaluate: String
    var remark: String
    var monthly_evaluate: String
    var promulgator_consent: String
    var accepter_consent: String
    
    //初始化
    init(promulgator: String, accepter: String, time: String, task_id: String, project: String, function_module: String, plan_time: String, practical_time: String, subentry_evaluate: String, remark: String, monthly_evaluate: String, promulgator_content: String, accepter_consent: String) {
        
        self.promulgator = promulgator
        self.accepter = accepter
        self.time = time
        self.task_id = task_id
        self.project = project
        self.function_module = function_module
        self.plan_time = plan_time
        self.practical_time = practical_time
        self.subentry_evaluate = subentry_evaluate
        self.remark = remark
        self.monthly_evaluate = monthly_evaluate
        self.promulgator_consent = promulgator_content
        self.accepter_consent = accepter_consent
    }
    
    
    
}
