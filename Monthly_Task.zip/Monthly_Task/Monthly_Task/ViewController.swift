//
//  ViewController.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

     

        // Do any additional setup after loading the view.
    }


}

