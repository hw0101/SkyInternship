//
//  PostTaskViewController.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/23.
//

import UIKit

//發布任務界面
class PostTaskView: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //MARK:-連結控件
    //連接Label控件
    @IBOutlet weak var promulgatorLabel: UILabel!
    @IBOutlet weak var accepterLabel: UILabel!
    @IBOutlet weak var projectLabel: UILabel!
    @IBOutlet weak var functionModuleLabel: UILabel!
    @IBOutlet weak var planTimeLabel: UILabel!
    @IBOutlet weak var praticalTimeLabel: UILabel!
    @IBOutlet weak var subentryEvaluateLabel: UILabel!
    @IBOutlet weak var monthlyEvaluateLabel: UILabel!
    @IBOutlet weak var remarkLabel: UILabel!

    //連接TextField控件
    @IBOutlet weak var promulgatorContent: UITextField!
    @IBOutlet weak var accepterContent: UITextField!
    @IBOutlet weak var projectContent: UITextField!
    @IBOutlet weak var functionModuleContent: UITextField!
    @IBOutlet weak var planTimeContent: UITextField!
    @IBOutlet weak var practicalTimeContent: UITextField!
    @IBOutlet weak var subentryEvaluateContent: UITextField!
    @IBOutlet weak var monthlyEvaluateContent: UITextField!
    @IBOutlet weak var remarkContent: UITextField!
    
    //連接按鈕
    @IBOutlet weak var submitButton: UIButton!
    
    //連結picerView相關控件
    @IBOutlet weak var accepterPickerView: UIPickerView!
    @IBOutlet weak var accepterPickerViewToolBar: UIToolbar!
    @IBOutlet weak var confirmButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    
    //MARK:-變量設置
    //變量設置
    var selectedRow: Int?
    var selectedAccepter = ""
    var controller = SearchTaskTwoView()
        
    override func viewDidLoad() {
        super.viewDidLoad()

        print("this is postTaskView")
        
        //標題設置
        self.title = "发布任务"
        
        //設置背景顏色
        self.view.backgroundColor = UIColor.systemBlue
        
        //設置tabbarItem的背景圖片
        self.tabBarItem.image = UIImage(named: "posttask")
        
        //View添加Label
        self.view.addSubview(projectContent)
        self.view.addSubview(accepterLabel)
        self.view.addSubview(projectLabel)
        self.view.addSubview(functionModuleLabel)
        self.view.addSubview(planTimeLabel)
        self.view.addSubview(praticalTimeLabel)
        self.view.addSubview(subentryEvaluateLabel)
        self.view.addSubview(monthlyEvaluateLabel)
        self.view.addSubview(remarkLabel)
        
        //View添加TextField
        self.view.addSubview(promulgatorContent)
        self.view.addSubview(accepterContent)
        self.view.addSubview(projectContent)
        self.view.addSubview(functionModuleContent)
        self.view.addSubview(planTimeContent)
        self.view.addSubview(practicalTimeContent)
        self.view.addSubview(subentryEvaluateContent)
        self.view.addSubview(monthlyEvaluateContent)
        self.view.addSubview(remarkContent)
        
        //設置TextField sizeToFit
        self.promulgatorContent.sizeToFit()
        self.accepterContent.sizeToFit()
        self.projectContent.sizeToFit()
        self.functionModuleContent.sizeToFit()
        self.planTimeContent.sizeToFit()
        self.practicalTimeContent.sizeToFit()
        self.subentryEvaluateContent.sizeToFit()
        self.monthlyEvaluateContent.sizeToFit()
        self.remarkContent.sizeToFit()
    
        //View添加Button
        self.view.addSubview(submitButton)
        
        //View添加PickerView
        self.view.addSubview(accepterPickerView)
        
        //設置接收者文本框的默認值為空字符串
        self.accepterContent.text = ""
        
        //PickerView代理設置
        self.accepterPickerView.dataSource = self
        self.accepterPickerView.delegate = self
        self.accepterPickerView.removeFromSuperview()
        self.accepterPickerViewToolBar.removeFromSuperview()
        
        //设置Autolayout，關閉控件的translatesAutoresizingMaskIntoConstraints
        self.promulgatorLabel.translatesAutoresizingMaskIntoConstraints = false
        self.accepterLabel.translatesAutoresizingMaskIntoConstraints = false
        self.planTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        self.functionModuleLabel.translatesAutoresizingMaskIntoConstraints = false
        self.praticalTimeLabel.translatesAutoresizingMaskIntoConstraints = false
        self.projectLabel.translatesAutoresizingMaskIntoConstraints = false
        self.subentryEvaluateLabel.translatesAutoresizingMaskIntoConstraints = false
        self.remarkLabel.translatesAutoresizingMaskIntoConstraints = false
        self.monthlyEvaluateLabel.translatesAutoresizingMaskIntoConstraints = false
        
        //设置Autolayout，關閉控件的translatesAutoresizingMaskIntoConstraints
        self.promulgatorContent.translatesAutoresizingMaskIntoConstraints = false
        self.accepterContent.translatesAutoresizingMaskIntoConstraints = false
        self.projectContent.translatesAutoresizingMaskIntoConstraints = false
        self.functionModuleContent.translatesAutoresizingMaskIntoConstraints = false
        self.planTimeContent.translatesAutoresizingMaskIntoConstraints = false
        self.practicalTimeContent.translatesAutoresizingMaskIntoConstraints = false
        self.subentryEvaluateContent.translatesAutoresizingMaskIntoConstraints = false
        self.monthlyEvaluateContent.translatesAutoresizingMaskIntoConstraints = false
        self.remarkContent.translatesAutoresizingMaskIntoConstraints = false
        self.submitButton.translatesAutoresizingMaskIntoConstraints = false
        
        //設置輸入框為圓角
        self.promulgatorContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.accepterContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.projectContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.functionModuleContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.planTimeContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.practicalTimeContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.subentryEvaluateContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.monthlyEvaluateContent.borderStyle = UITextField.BorderStyle.roundedRect
        self.remarkContent.borderStyle = UITextField.BorderStyle.roundedRect
        
        //設置輸入框masksToBounds
        self.promulgatorContent.layer.masksToBounds = true
        self.accepterContent.layer.masksToBounds = true
        self.projectContent.layer.masksToBounds = true
        self.functionModuleContent.layer.masksToBounds = true
        self.planTimeContent.layer.masksToBounds = true
        self.practicalTimeContent.layer.masksToBounds = true
        self.subentryEvaluateContent.layer.masksToBounds = true
        self.monthlyEvaluateContent.layer.masksToBounds = true
        self.remarkContent.layer.masksToBounds = true
    
        //設置圓角半徑
        self.promulgatorContent.layer.cornerRadius = 12.0
        self.accepterContent.layer.cornerRadius = 12.0
        self.projectContent.layer.cornerRadius = 12.0
        self.functionModuleContent.layer.cornerRadius = 12.0
        self.planTimeContent.layer.cornerRadius = 12.0
        self.practicalTimeContent.layer.cornerRadius = 12.0
        self.subentryEvaluateContent.layer.cornerRadius = 12.0
        self.monthlyEvaluateContent.layer.cornerRadius = 12.0
        self.promulgatorContent.layer.cornerRadius = 12.0
        self.remarkContent.layer.cornerRadius = 12.0

        //設置邊框寬度
        self.promulgatorContent.layer.borderWidth = 1.0
        self.accepterContent.layer.borderWidth = 1.0
        self.projectContent.layer.borderWidth = 1.0
        self.functionModuleContent.layer.borderWidth = 1.0
        self.planTimeContent.layer.borderWidth = 1.0
        self.practicalTimeContent.layer.borderWidth = 1.0
        self.subentryEvaluateContent.layer.borderWidth = 1.0
        self.monthlyEvaluateContent.layer.borderWidth = 1.0
        self.promulgatorContent.layer.borderWidth = 1.0
        self.remarkContent.layer.borderWidth = 1.0
        
        //設置各個textField的代理
        self.promulgatorContent.delegate = self
        self.accepterContent.delegate = self
        self.projectContent.delegate = self
        self.functionModuleContent.delegate = self
        self.planTimeContent.delegate = self
        self.practicalTimeContent.delegate = self
        self.subentryEvaluateContent.delegate = self
        self.monthlyEvaluateContent.delegate = self
        self.promulgatorContent.delegate = self
        self.remarkContent.delegate = self 
        
        //accepterContentTextField的相關設置
        self.accepterContent.inputView = self.accepterPickerView
        self.accepterContent.inputAccessoryView = self.accepterPickerViewToolBar
        self.accepterPickerView.backgroundColor = UIColor.systemBlue
        
        //ToolBar confirmButton和cancelButton按鈕的設置
        self.confirmButton.action = #selector(confirm)
        self.cancelButton.action = #selector(cancel)
        
        //設定發送者和接受者的文本對齊方式為居中
        self.promulgatorContent.textAlignment = .center
        self.accepterContent.textAlignment = .center
        
        //設置發送者為登陸用戶
        self.promulgatorContent.text = LoginView.loginedUserName
        
        //設置提交按鈕的功能
        self.submitButton.addTarget(self, action: #selector(postTask), for: .touchUpInside)
        
        //獲取用戶名單
        UserListTableView().getUserList()
        
        setAutoLayOut()
        setFontSize()
    }
    
 
    func setFontSize() {
       
        self.promulgatorLabel.font = UIFont.systemFont(ofSize: 17)
        self.accepterLabel.font = UIFont.systemFont(ofSize: 17)
        self.planTimeLabel.font = UIFont.systemFont(ofSize: 17)
        self.functionModuleLabel.font = UIFont.systemFont(ofSize: 17)
        self.praticalTimeLabel.font = UIFont.systemFont(ofSize: 17)
        self.projectLabel.font = UIFont.systemFont(ofSize: 17)
        self.subentryEvaluateLabel.font = UIFont.systemFont(ofSize: 17)
        self.remarkLabel.font = UIFont.systemFont(ofSize: 17)
        self.monthlyEvaluateLabel.font = UIFont.systemFont(ofSize: 17)
    
    }
    
    
    func setAutoLayOut() {
        
        //projectLabel
        self.promulgatorLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 30).isActive = true
        self.promulgatorLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30).isActive = true
    
        //accepterLabel
        self.accepterLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 70).isActive = true
        self.accepterLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30).isActive = true
        
        //projectLabel
        self.projectLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 110).isActive = true
        self.projectLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 35).isActive = true
        
        //functionModuleLabel
        self.functionModuleLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 150).isActive = true
        self.functionModuleLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 22).isActive = true
    
        //planTimeLabel
        self.planTimeLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 190).isActive = true
        self.planTimeLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 15).isActive = true
        
        //praticalTimeLabel
        self.praticalTimeLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 230).isActive = true
        self.praticalTimeLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 22).isActive = true
       
        //subentryEvaluateLabel
        self.subentryEvaluateLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 270).isActive = true
        self.subentryEvaluateLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 22).isActive = true
        
        //monthlyEvaluateLabel
        self.monthlyEvaluateLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 310).isActive = true
        self.monthlyEvaluateLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 22).isActive = true
        
        //remarkLabel
        self.remarkLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 350).isActive = true
        self.remarkLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 35).isActive = true
        
         //promulgatorContent
        self.promulgatorContent.centerYAnchor.constraint(equalTo: self.promulgatorLabel.centerYAnchor).isActive = true
        self.promulgatorContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.promulgatorContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.promulgatorContent.heightAnchor.constraint(equalToConstant: 33).isActive = true
        
        //accepterContent
        self.accepterContent.centerYAnchor.constraint(equalTo: self.accepterLabel.centerYAnchor).isActive = true
        self.accepterContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.accepterContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.accepterContent.heightAnchor.constraint(equalToConstant: 33).isActive = true

        //projectContent
        self.projectContent.centerYAnchor.constraint(equalTo: self.projectLabel.centerYAnchor).isActive = true
        self.projectContent.leadingAnchor.constraint(equalTo:  self.view.leadingAnchor, constant: 120).isActive = true
        self.projectContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.projectContent.heightAnchor.constraint(equalToConstant: 33).isActive = true
        
       //functionModuleContent
        self.functionModuleContent.centerYAnchor.constraint(equalTo: self.functionModuleLabel.centerYAnchor).isActive = true
        self.functionModuleContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.functionModuleContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.functionModuleContent.heightAnchor.constraint(equalToConstant: 33).isActive = true

       //planTimeContent
        self.planTimeContent.centerYAnchor.constraint(equalTo: self.planTimeLabel.centerYAnchor).isActive = true
        self.planTimeContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.planTimeContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.planTimeContent.heightAnchor.constraint(equalToConstant: 33).isActive = true
     
        //practicalTimeContent
        self.practicalTimeContent.centerYAnchor.constraint(equalTo:self.praticalTimeLabel.centerYAnchor).isActive = true
        self.practicalTimeContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.practicalTimeContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.practicalTimeContent.heightAnchor.constraint(equalToConstant: 33).isActive = true
        
        //subentryEvaluateContent
        self.subentryEvaluateContent.centerYAnchor.constraint(equalTo: self.subentryEvaluateLabel.centerYAnchor).isActive = true
        self.subentryEvaluateContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.subentryEvaluateContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.subentryEvaluateContent.heightAnchor.constraint(equalToConstant: 33).isActive = true

        //monthlyEvaluateContent
        self.monthlyEvaluateContent.centerYAnchor.constraint(equalTo: self.monthlyEvaluateLabel.centerYAnchor).isActive = true
        self.monthlyEvaluateContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.monthlyEvaluateContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.monthlyEvaluateContent.heightAnchor.constraint(equalToConstant: 33).isActive = true

        //remarkContent
        self.remarkContent.centerYAnchor.constraint(equalTo: self.remarkLabel.centerYAnchor).isActive = true
        self.remarkContent.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.remarkContent.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -20).isActive = true
        self.remarkContent.heightAnchor.constraint(equalToConstant: 33).isActive = true
        
        //View添加Button
        self.submitButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        self.submitButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 390).isActive = true
    }
    
    //MARK:-發布任務函數
    //發布任務函數
    @objc func postTask() {
        
        //判斷接收者是否為空，防止程序因值報錯
        if (accepterContent.text == "") {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "😺提醒", message: "未選擇接收者", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: false, completion: nil)
            }
        } else if (accepterContent.text != "") {
               let promulgatorGrade = Int(LoginView.loginedUserGrade)
               let accepterGrade = Int(UserListTableView.user[selectedRow!].user_grade)
        
               print(promulgatorGrade)
               print(accepterGrade)
              
              //任務發送者等級如果等於或者大於任務接受者等級，則調用發送任務函數
              if ((promulgatorGrade!) >= (accepterGrade!)) {
                  postJSONTask()
              //如果發送者等級小於接收者等級，則彈出提示框。
              } else if ((promulgatorGrade!) < (accepterGrade!)) {
                   DispatchQueue.main.async {
                       let alert = UIAlertController(title: "😺提醒", message: "发布者等级低于接收者，请重新选择接受者", preferredStyle: UIAlertController.Style.alert)
                       alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                       self.present(alert, animated: false, completion: nil)
                   }
              }
         }
    }
        
    //上傳JSON函數
    @objc func postJSONTask() {
        
        let promulgator = LoginView.loginedUser.user_id as! String
        let accepter = UserListTableView.user[selectedRow!].user_id as! String
        
        print("this is postTask")
        
        //定義ContentJson數據
        let contentJSON: [String: Any] = ["practical_time": self.practicalTimeContent.text,
                                          "function_module": self.functionModuleContent.text,
                                          "plan_time": self.planTimeContent.text,
                                          "project": self.projectContent.text,
                                          "subentry_evaluate": self.subentryEvaluateContent.text,
                                          "remark": self.remarkContent.text,
                                          "monthly_evaluate": self.monthlyEvaluateContent.text
                                         ]
        //定義需要上傳到服務器的postJSON
        let postJSON: [String: Any] = ["promulgator": promulgator,
                                       "accepter": accepter,
                                       "content": [contentJSON]
                                      ]
        
        let jsonData = try? JSONSerialization.data(withJSONObject: postJSON)

        //設置url地址
        //線上地址
        let url = URL(string: "http://192.168.31.22:8082/addTask")!
        
        //本地
        // let url = URL(string: "http://192.168.31.35:8082/addTask")!
               
        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將json插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)

            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中data的值
                let individualJSONData = responseJSONData["data"]
                
                //取出[String: Any]字典中的state的值
                let stateString = Util.toString(responseJSONData["state"])
                let stateValue = Int(stateString)!
                
                //根据state的数值弹出提示框
                //成功弹出成功提示框
                if (stateValue >= 0) {
                    showSuccessAlert()
                //失败弹出失败提示框
                } else if (stateValue < 0) {
                    showFailAlert()
                }
            }
        }
        task.resume()
    }
    
    //顯示發布任務成功提示框
    func showSuccessAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "提醒", message: "发布任务成功", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: false, completion: nil)
        }
    }
    
    //顯示發布任務失敗提示框
    func showFailAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "提醒", message: "请输入正确的任务信息", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: false, completion: nil)
        }
    }
    
    //MARK:-鍵盤彈出相關設置
    //設置鍵盤彈出位置變化效果
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
        
    @objc func keyboardWillShow(notification: NSNotification) {
        guard let userInfo = notification.userInfo else {return}
        guard let keyboardSize = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else {return}
            let keyboardFrame = keyboardSize.cgRectValue

            if self.view.bounds.origin.y == 0 {
            self.view.bounds.origin.y += keyboardFrame.height - 200
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.bounds.origin.y != 0 {
           self.view.bounds.origin.y = 0
        }
    }
       
    //設置當點View時收回鍵盤
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //設置textField Return按下textField取消成為第一響應者
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    
    //MARK:-PickerView代理以及相關函數
    //設置pickerview顯示列數
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
         return 1
    }
    
    //設置pickerView數據顯示數目
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return UserListTableView.user.count
    }
    
    //設置pickerView數據內容
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
       // return SearchTaskTwoView.nameList[row]
        return UserListTableView.user[row].name
    }
    
    //PickerView確認數據
    @objc func confirm() {
        selectedRow = accepterPickerView.selectedRow(inComponent: 0)
        print("this is selectedRow", selectedRow)
        self.accepterContent.text = UserListTableView.user[selectedRow!].name
        //    self.accepterContent.text = selectedAccepter
        self.accepterContent.resignFirstResponder()
    }
    
    //點擊ToolBar取消按鈕關閉鍵盤
    @objc func cancel() {
        self.accepterContent.resignFirstResponder()
    }

    
    
}


